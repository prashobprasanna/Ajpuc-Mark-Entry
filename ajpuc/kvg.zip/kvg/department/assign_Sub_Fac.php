<?php include('header.php');
include('sidebar.php');
extract($_REQUEST);?>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php 
    $tm = "SELECT Name FROM subjects WHERE sem=1";
    $sm = $con->query($tm);
    $res1='';
    while($row = $sm->fetch_assoc()){
        $res1=$res1."<option>".$row['Name']."</option>"; 
        }
  ?>
<?php 
    $tm = "SELECT Name FROM subjects WHERE sem=2";
    $sm = $con->query($tm);
    $res2='';
    while($row = $sm->fetch_assoc()){
        $res2=$res2."<option>".$row['Name']."</option>"; 
        }
  ?>
<?php 
    $tm = "SELECT Name FROM subjects WHERE sem=3";
    $sm = $con->query($tm);
    $res3='';
    while($row = $sm->fetch_assoc()){
        $res3=$res3."<option>".$row['Name']."</option>"; 
        }
  ?>
  <?php 
    $tm = "SELECT Name FROM subjects WHERE sem=4";
    $sm = $con->query($tm);
    $res4='';
    while($row = $sm->fetch_assoc()){
        $res4=$res4."<option>".$row['Name']."</option>"; 
        }
  ?>
<?php 
    $tm = "SELECT Name FROM subjects WHERE sem=5";
    $sm = $con->query($tm);
    $res5='';
    while($row = $sm->fetch_assoc()){
        $res5=$res5."<option>".$row['Name']."</option>"; 
        }
  ?>
<?php 
    $tm = "SELECT Name FROM subjects WHERE sem=6";
    $sm = $con->query($tm);
    $res6='';
    while($row = $sm->fetch_assoc()){
        $res6=$res6."<option>".$row['Name']."</option>"; 
        }
  ?>
<?php 
    $tm = "SELECT Name FROM subjects WHERE sem=7";
    $sm = $con->query($tm);
    $res7='';
    while($row = $sm->fetch_assoc()){
        $res7=$res7."<option>".$row['Name']."</option>"; 
        }
  ?>
<?php 
    $tm = "SELECT Name FROM subjects WHERE sem=8";
    $sm = $con->query($tm);
    $res8='';
    while($row = $sm->fetch_assoc()){
        $res8=$res8."<option>".$row['Name']."</option>"; 
        }
  ?>
<script type="text/javascript">
    $(document).ready(function() {

  $("#source").change(function() {

    var el = $(this) ;

    if(el.val() === "1" ) {
      var app='<?php echo $res1 ;?>';
      $("#status option").remove()
    $("#status").append(app);
    }
      else if(el.val() === "2" ) {
        var app1='<?php echo $res2 ;?>';
        $("#status option").remove()
    $("#status").append(app1); }
    else if(el.val() === "3" ) {
       var app2='<?php echo $res3 ;?>';
       $("#status option").remove()
    $("#status").append(app2); ; }
    else if(el.val() === "4" ) {
        var app3='<?php echo $res4 ;?>';
        $("#status option").remove()
    $("#status").append(app3); }
    else if(el.val() === "5" ) {
        var app3='<?php echo $res5 ;?>';
        $("#status option").remove()
    $("#status").append(app3); }
    else if(el.val() === "6" ) {
        var app3='<?php echo $res6 ;?>';
        $("#status option").remove()
    $("#status").append(app3); }
    else if(el.val() === "7" ) {
        var app3='<?php echo $res7 ;?>';
        $("#status option").remove()
    $("#status").append(app3); }
    else if(el.val() === "8" ) {
        var app3='<?php echo $res8 ;?>';
        $("#status option").remove()
    $("#status").append(app3); }
  });

});
 
</script>

<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>
      Assign Subject To Faculty
      </h1>
      <ol class="breadcrumb">
         <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
         <li class="active">Assign Subject to Faculty</li>
      </ol>
      <div class="content">
         <div class="container-fluid">
            <?php
            if(isset($success)){?>
            <div class="alert alert-success" role="alert">
               <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
               <strong>Subject is assigned sucessfully</strong>
            </div>
            <?php }
            ?>
            <?php
            if(isset($error)){?>
            <div class="alert alert-warning" role="alert">
               <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
               <strong>Subject is not assigned at this time try again!</strong>
            </div>
            <?php }
            ?>
            <a href="subfaclist.php" class="btn btn-primary pull-right">List Subjects Assigned</a>
         <br/><br/>
            <div class="panel panel-info">
               <div class="panel-heading">Assign Subject to Faculty </div>
               <div class="panel-body">
                  <form class="form-horizontal" role="form" method="post" action="saveSubject.php" enctype="multipart/form-data">
                    
                     <div class="form-group">
                        <div class="col-md-4 col-sm-4 col-sx-12">
                           <label for="fac" class="control-label">Faculty</label><span id="sp">:</span> 
                        </div>
                        <div class="col-md-6 col-sm-6 col-sx-12">
                            <select name="fac">
                            <?php 
                      $tm    = "SELECT Name FROM faculty";
                        $tmresult = $con->query($tm); 
                       while($row = $tmresult->fetch_assoc()){
                             echo "<option value='".$row['Name']."'>".$row['Name']."</option>";}        
                      ?>
                            
                              
                            </select>
                        </div>
                     </div>
                      
                     <div class="form-group">
                        <div class="col-md-4 col-sm-4 col-sx-12">
                           <label for="name" class="control-label">SEM </label><span id="sp">:</span>
                        </div>
                        <div class="col-md-6 col-sm-6 col-sx-12">
                              
                            <select id="source" name="source">
                                <option disabled selected value> -- select an option -- </option>
                                 <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                 <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                            </select>


                        </div>
                     </div>
                    
                     <div class="form-group">
                        <div class="col-md-4 col-sm-4 col-sx-12">
                           <label for="name" class="control-label">Subject </label><span id="sp">:</span>
                        </div>
                        <div class="col-md-6 col-sm-6 col-sx-12">
                            
                            <select id="status" name="status">
                                <option>please select</option>

                              
                            </select>
                        </div>
                     </div>
                     
                  
                     <br>
                     <div class="col-md-10 col-sm-10 col-sx-12">
                        <input id="submit" name="submit" type="submit" value="Assign Subject" class="btn btn-success pull-right">
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </section>
</div>
<?php include("footer.php");?>