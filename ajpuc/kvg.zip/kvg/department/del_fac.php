<?php
extract($_REQUEST);
include("dbconfig.php");

$sql = "DELETE FROM faculty WHERE idn=$oldid";
$result = $con->query($sql);

if($result == True ){
   echo "<script>window.location.assign('Faculty_List.php?delsuccess=true');</script>";
}
else{
    echo "<script>window.location.assign('Faculty_List.php?delerror=true');</script>";
}